﻿namespace T4PR1.Models
{
    public class EnergyManager
    {
        private const string SimulationsFilePath = "Data/simulacions_energia.csv";
       
        public EnergyManager()
        {
            
            FileExistsOrDefault();
            
        }

        public void addLine(DateTime simDate, EnergyTypeEnum energyType, float ratio, float parameter, double kWhCost, double kWhPrice, double generatedEnergy)
        {
           
            using (var writer = new StreamWriter(SimulationsFilePath, true))
            {
                
                          
                writer.WriteLine($"{simDate},{energyType},{parameter},{ratio},{generatedEnergy},{kWhCost},{kWhPrice},{Math.Round(kWhCost * generatedEnergy, 2)},{Math.Round(kWhPrice * generatedEnergy, 2)}");
            }


        }
        private void FileExistsOrDefault()
        {
            string? directory = Path.GetDirectoryName(SimulationsFilePath);
            if (!Directory.Exists(directory))
            {
                if (directory != null) Directory.CreateDirectory(directory);
            }

            if (!File.Exists(SimulationsFilePath))
            {
                using (var headWriter = new StreamWriter(SimulationsFilePath))
                {
                    headWriter.WriteLine("Data,Tipus,Parametre,Rati,EnergiaGenerada,CostKWh,PreuKWh,CostTotal,PreuTotal");
                }
            }
           
           

        }

        public List<Energy> LoadSimulations()
        {
            var simulations = new List<Energy>();

            try
            {
                if (File.Exists(SimulationsFilePath))
                {
                    var lines = File.ReadAllLines(SimulationsFilePath).Skip(1);

                    foreach (string line in lines)
                    {
                        string[] parts = line.Split(',');
                       // if (parts.Length < 10) continue;

                        Energy energy = new Energy();

                        
                        energy.SimDate = DateTime.Parse(parts[0]);
                        energy.EnergyType = (EnergyTypeEnum)Enum.Parse(typeof(EnergyTypeEnum), parts[1]);
                        energy.Parameter = float.Parse(parts[2]);
                        energy.Ratio = float.Parse(parts[3]);
                        energy.GeneratedEnergy = double.Parse(parts[4]);
                        energy.KWhCost = double.Parse(parts[5]);
                        energy.KWhPrice = double.Parse(parts[6]);
                        
                        energy.KWhCostTotal = double.Parse(parts[7]);
                        energy.KWhPriceTotal = double.Parse(parts[8]);
                        simulations.Add(energy);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading simulations: {ex.Message}");
            }

            return simulations;
        }

        
    }
}
