﻿namespace T4PR1.Models
{
    public class EnergySystem
    {
    }
}
