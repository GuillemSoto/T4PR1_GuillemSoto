using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace T4PR1.Pages
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
