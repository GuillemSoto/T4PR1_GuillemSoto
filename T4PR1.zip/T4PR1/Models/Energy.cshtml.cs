﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace T4PR1.Models
{
    public enum EnergyTypeEnum
    {
        Solar,
        Eolica,
        Hidroelectrica
    }

    public class Energy : PageModel
    {
        public double KWhPriceTotal { get; set; }
        public double KWhCostTotal { get; set; }
        const string OorMsg = "El número està fora del rang";
        public DateTime SimDate { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "Es requereix un tipus d'energia.")]
        public EnergyTypeEnum EnergyType { get; set; }

        [Required(ErrorMessage = "Es requereix un rati.")]
        [Range(0, 3, ErrorMessage = "El rati ha d'estar entre 0 i 3.")]
        public float Ratio { get; set; }

        private float _Parameter;
        [Required(ErrorMessage = "Es requereix un paràmetre.")]
        public float Parameter
        {
            get { return _Parameter; }
            set
            {               
                _Parameter = value; 
            }
        }

        [Required(ErrorMessage = "Es requereix un cost.")]
        public double KWhCost { get; set; }

        [Required(ErrorMessage = "Es requereix un preu.")]
        public double KWhPrice { get; set; }
        public List<Energy> Simulators=new List<Energy>();
        public double GeneratedEnergy
        {
            get
            {
                double generatedEnergy = 0;
                switch (EnergyType)
                {
                    case EnergyTypeEnum.Solar:
                        generatedEnergy = Math.Round(Parameter * Ratio,2);
                        break;
                    case EnergyTypeEnum.Eolica:
                        generatedEnergy = Math.Round(Math.Pow(Parameter, 3) * Ratio,2);
                        break;
                    case EnergyTypeEnum.Hidroelectrica:
                        generatedEnergy = Math.Round(Parameter * Ratio * 9.8,2);
                        break;
                    default:
                        throw new ValidationException("Error");
                }
                return generatedEnergy;
            }
            set { }
        }

        public IActionResult OnGet()
        {
           
            EnergyType = EnergyTypeEnum.Solar;
            return Page();
        }

        public IActionResult OnPost()
        {
            EnergyType = (EnergyTypeEnum)Enum.Parse(typeof(EnergyTypeEnum), Request.Form["EnergyType"]);
            Ratio = float.Parse(Request.Form["Ratio"]);
            Parameter = float.Parse(Request.Form["Parameter"]);
            KWhCost = double.Parse(Request.Form["KWhCost"]);
            KWhPrice = double.Parse(Request.Form["KWhPrice"]);
            if (EnergyType == EnergyTypeEnum.Solar && Parameter < 1)
            {
                ModelState.AddModelError(nameof(Parameter),OorMsg);
            }
            if (EnergyType == EnergyTypeEnum.Eolica && Parameter < 5)
            {
                ModelState.AddModelError(nameof(Parameter), OorMsg); 
            }
            if (EnergyType == EnergyTypeEnum.Hidroelectrica && Parameter < 20)
            {
                ModelState.AddModelError(nameof(Parameter), OorMsg);
            }
            if (!ModelState.IsValid)
            {
                return Page();
            }
            
            ;
           
            EnergyManager energyManager = new EnergyManager();
            energyManager.addLine(SimDate, EnergyType, Ratio, Parameter, KWhCost, KWhPrice, GeneratedEnergy);
            return RedirectToPage("./Simulations");
        }
    }
}