﻿namespace T4PR1.Models
{
    public enum CataloniaRegion
    {
        Vall_d_Aran,
        AltaRibagorça,
        PallarsSobirà,
        PallarsJussà,
        AltUrgell,
        Cerdanya,
        Berguedà,
        Solsonès,
        Ripollès,
        Garrotxa,
        AltEmpordà,
        BaixEmpordà,
        LaSelva,
        Maresme,
        Barcelonès,
        BaixLlobregat,
        Garraf,
        BaixPenedès,
        Tarragonès,
        BaixCamp,
        BaixEbre,
        Montsià,
        PlaEstany,
        Gironès,
        VallèsOriental,
        VallèsOccidental,
        AltCamp,
        AltPenedès,
        Noguera,
        Segrià,
        PlaUrgell,
        Urgell,
        Segarra,
        Anoia,
        Garrigues,
        ConcaBarberà,
        Bages,
        Osona,
        TerraAlta,
        RiberaEbre,
        Priorat
    }
    public class WaterConsumption
    {
        public int Year = 2024;
        public int Id { get; set; }
        public CataloniaRegion Region { get; set; }
        public int Population { get; set; }
        public int DomesticNet { get; set; }
        public int EconActivity { get; set; }
        public decimal DomesticConsume { get; set; }
        public WaterConsumption(int year, int id, CataloniaRegion region, int population, int domesticNet, int econActivity, decimal domesticConsume)
        {
            Year = year;
            Id = id;
            Region = region;
            Population = population;
            DomesticNet = domesticNet;
            EconActivity = econActivity;
            DomesticConsume = domesticConsume;
        }
    }
}
