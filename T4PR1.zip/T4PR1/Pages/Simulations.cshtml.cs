﻿using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace T4PR1.Models
{

    public class Simulations : PageModel
    {

        public List<Energy> simulations { get; set; }
        public int registers { get; set; }
        
        public IActionResult OnGet()
        {
           
            EnergyManager controler = new EnergyManager(); 
            simulations = controler.LoadSimulations();
            registers = simulations.Count();
            
            return Page();
        }

        public IActionResult OnPost()
        {
            
            return RedirectToPage("./Simulations");
        }
    }
}